/**
 * Automatically generated file. DO NOT MODIFY
 */
package biz.cosee.native_image_cropper_android;

public final class BuildConfig {
  public static final boolean DEBUG = Boolean.parseBoolean("true");
  public static final String LIBRARY_PACKAGE_NAME = "biz.cosee.native_image_cropper_android";
  public static final String BUILD_TYPE = "debug";
}
