/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.example.cashbaba_merchant_sdk;

public final class BuildConfig {
  public static final boolean DEBUG = Boolean.parseBoolean("true");
  public static final String LIBRARY_PACKAGE_NAME = "com.example.cashbaba_merchant_sdk";
  public static final String BUILD_TYPE = "profile";
}
